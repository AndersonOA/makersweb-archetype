#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * 
 */
package ${package}.service;

import java.util.Map;

/**
 *
 * @author Anderson O. Aristides
 *
 */
public interface IEmailSenderService {
	
	Boolean sendTestEmail(String email, Map<String, Object> data);

}
